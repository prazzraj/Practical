#include<iostream>
using namespace std;

class Remainder
{
    int M[2][10], n = 3;

    public:
    int Calculate(int [10], int [10], int);
    int CalculateModulus(int [10], int [10]);
    void CalculateModulusInverse(int [10]);
};

int Remainder::Calculate(int mod[10], int rem[10], int count)
{
    int Modulus, i, Result = 0;
    n = count;

    Modulus = CalculateModulus(mod, rem);
    CalculateModulusInverse(mod);

    for(i = 0; i < n; i++)
    {
        Result += rem[i] * M[0][i] * M[1][i];
    }
    Result = Result % Modulus;

    return Result;
}

int Remainder::CalculateModulus(int mod[10], int rem[10])
{
    int i, Modulus = 1;

    for(i = 0; i < n; i++)
        Modulus *= mod[i];

    for(i = 0; i < n; i++)
        M[0][i] = Modulus / mod[i];

    return Modulus;
}

void Remainder::CalculateModulusInverse(int mod[10])
{
    for(int i = 0; i < n; i++)
        M[1][i] = M[0][i] % mod[i];
}

int main()
{
    int mod[10], rem[10], count, i, Result;
    Remainder obj;

    cout << "\nEnter count of Divisiors: ";
    cin >> count;

    for(i = 0; i < count; i++)
    {
        cout << "\nEnter Divisior: ";
        cin >> mod[i];
        cout << "Enter Remainder: ";
        cin >> rem[i];
    }

    Result = obj.Calculate(mod, rem, count);
    cout << "\nResult is: " << Result << "\n";

    return 0;
}